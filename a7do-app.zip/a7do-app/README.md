# A7DO App

A7DO Development & Cognition App (Proto-Cognition Only)

- No awareness
- No identity
- No memory writes

Backed by Airtable and stage-gated.
